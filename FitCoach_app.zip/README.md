# FitCoach – Gym & Diet

En enkel frontend-prototyp för en app som hjälper användaren med träning och kost.

## Starta
Öppna `index.html` i en webbläsare.

## Funktioner
- Dashboard
- Träningspass med set/reps och viktlogg
- Övningsbibliotek med filter och sök
- Kostmål för gå ner / behålla / gå upp
- Enkel kaloriberäkning utifrån profil
- Responsiv design för mobil och dator

Detta är en prototyp. Kalorimål och kostrekommendationer är uppskattningar och bör inte betraktas som medicinsk rådgivning.
